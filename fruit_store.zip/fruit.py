from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['GET','POST'])
def show_order():
    name = request.form['name']
    student_id = request.form['student_id']
    pineapple = request.form.get('pineapple')
    apple = request.form.get('apple')
    banana = request.form.get('banana')
    return render_template('checkout.html', name=name, student_id=student_id, pineapple=str(pineapple), apple=str(apple), banana=str(banana))

app.run(debug=True)    
